import { useNavigate, useParams } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";


function ProductUpdate() {
    // console.log(useParams())
    const {id}=useParams()
    const[name,setName]=useState('')
    const[desc,setDesc]=useState('')
    const[ldesc,setLdesc]=useState('')
    const[price,setPrice]=useState('')
    const[status,setStatus]=useState('')
    const[message,setMessage]=useState('')
      const navigate=useNavigate()
   useEffect(()=>{
        fetch(`/api/singleproduct/${id}`).then((result)=>{return result.json()}).then((data)=>{
            console.log(data)
            if(data.status===200){
                setName(data.apiData.name)
                setDesc(data.apiData.desc)
                setLdesc(data.apiData.ldesc)
                setPrice(data.apiData.price)
                setStatus(data.apiData.status)
            }else{
                setMessage(data.message)
            }
        })
    },[])

    function handleform(e){
        e.preventDefault()
        const formdata={name,desc,ldesc,price,status}
        fetch(`/api/productupdate/${id}`,{
            method:'PUT',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((result)=>{return result.json()}).then((data)=>{
            console.log(data)
            if(data.status===200){
                setMessage(data.message)
                navigate('/aminproducts')
            }else{
                setMessage(data.message)
                
            }
        })
    }
    return ( 
        <section id="dashboard">
      <div className="container">
        <div className="row">
           <Left/>
            <div className="col-md-9">
                {message}
            <form onSubmit={(e)=>{handleform(e)}}>
                        <label>Product Update Here</label>
                        <input type="text" className="form-control"
                        value={name}
                        onChange={(e)=>{setName(e.target.value)}}
                        />
                        <label>Product Description</label>
                        <input type="text" className="form-control"
                        value={desc}
                        onChange={(e)=>{setDesc(e.target.value)}}
                        />
                        <label>Product Long Description</label>
                        <input type="text" className="form-control"
                        value={ldesc}
                        onChange={(e)=>{setLdesc(e.target.value)}}
                        />
                        <label>Product Price</label>
                        <input type="text" className="form-control"
                        value={price}
                        onChange={(e)=>{setPrice(e.target.value)}}
                        />
                        <label>Product Status</label>
                        <select value={status} className="form-select" onChange={(e)=>{setStatus(e.target.value)}}>
                            <option value='OUT STOCK'>OUT STOCK</option>
                            <option value='IN  STOCK'>IN STOCK</option>
                        </select>
                        <button type="submit" className="form-control  btn-dark mt-2 ">Update</button>
                        </form>
            </div>
           
        </div>
     </div>
     </section>
     );
}

export default  ProductUpdate;