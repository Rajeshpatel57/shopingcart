import { useState } from "react";
import Left from "./Left";

function ProductAdd() {
    const[name,setName]=useState('')
    const[desc,setDesc]=useState('')
    const[ldesc,setLdesc]=useState('')
    const[price,setPrice]=useState('')
    const[message,setMessage]=useState('')
    function handleform(e){
      e.preventDefault()
      //console.log(name,desc,ldesc,price)
       const formdata={name,desc,ldesc,price}
       fetch('api/productadd',{
        method:'POST',
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(formdata)
       }).then((result)=>{return result.json()}).then((data)=>{
         console.log(data)
         if(data.status===201){
            setMessage(data.Message)
         }else{
            setMessage(data.Message)
         }
       })
    }
    return ( 
        <section id="productadd">
            <div className="conainer">
                <div className="row justify-content-center">
                    <Left/>
                    <div className="col-md-6">
                       <h2>Product Add Here</h2>
                       <div className="alert alert-success ">{message}</div>
                       <form onSubmit={(e)=>{handleform(e)}}>
                        <label>Product Name</label>
                        <input type="text" className="form-control"
                        value={name}
                        onChange={(e)=>{setName(e.target.value)}}
                        />
                        <label>Product Description</label>
                        <input type="text" className="form-control"
                        value={desc}
                        onChange={(e)=>{setDesc(e.target.value)}}
                        />
                        <label>Product Long Description</label>
                        <input type="text" className="form-control"
                        value={ldesc}
                        onChange={(e)=>{setLdesc(e.target.value)}}
                        />
                        <label>Product Price</label>
                        <input type="text" className="form-control"
                        value={price}
                        onChange={(e)=>{setPrice(e.target.value)}}
                        />
                        <button type="submit" className="form-control  btn-dark mt-2 ">Add</button>
                        </form>
                    </div>

                </div>

            </div>
        </section>
     );
}

export default ProductAdd;