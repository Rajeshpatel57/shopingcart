import Left from "./Left";

function Dashboard() {
    return (
     <section id="dashboard">
      <div className="container">
        <div className="row">
           <Left/>
            <div className="col-md-9">mid</div>
           

        </div>

     </div>
     </section>
        
     ) 
       
}

export default Dashboard;