import { useContext } from "react";
import { Contextapi } from "../Contextapi";

function Productstr(props) {
  const{cart,setCart}=useContext(Contextapi)
   const{product}=props

   function handlecart(e,product){   
    console.log(product._id)
    let _cart={...cart}
    if(!_cart.item){
      _cart.item={}
    }
   if(!_cart.item[product._id]){
    _cart.item[product._id]=1
   }else{
    _cart.item[product._id]+=1
   }
 if(!_cart.totalitems){
  _cart.totalitems=1
 }else{
  _cart.totalitems +=1

 }
 setCart(_cart)
 console.log(cart)

   }
    return ( 
        <div className="col-md-3 mt-2">
        <div className="card" style={{ width:'17rem'}}>
     <img src="logo192.png" style={{width:'90px'}} className="card-img-top mx-auto d-block" alt="..."/>
     <div className="card-body">
       <h5 className="card-title">{product.name}</h5>
       <p className="card-text">{product.desc}</p>
       <p className="card-text">{product.price}</p>
       <button className="btn btn-warning me-1" onClick={(e)=>{handlecart(e,product)}}>Add to Card</button>
       <button className="btn btn-info">More details..</button>
     </div>
   </div>  
   </div>
     );
}

export default Productstr;