import { Link } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";
import ProductTable from "../ProductTable";

function Adminproducts() {
    const[products,setProducts]=useState([])
    const[message,setMessage]=useState('')
    useEffect(()=>{
        fetch('/api/allproducts').then((result)=>{return result.json()}).then((data)=>{
            console.log(data)
            if(data.status===200){
             setProducts(data.apiData)
            }else{
               setMessage(data.message)
            }
        })
    },[])
    return (
     <section id="dashboard">
      <div className="container">
        <div className="row">
           <Left/>
            <div className="col-md-9">
                <h2>Products Management</h2>
                <Link to='/productadd'><button className="btn btn-warning form-control">Product Add Here</button></Link>
                 {message}
                <ProductTable data={products}/>
            </div>
           

        </div>

     </div>
     </section>
        
     ) 
       
}

export default Adminproducts;