import { Link } from "react-router-dom";

function Left() {
    return ( 
        <div className="col-md-3">
            <Link to="/aminproducts"><button className="btn btn-info from-control ">Products Management</button></Link>
        </div>
     );
}

export default Left;