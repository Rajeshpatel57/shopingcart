import {BrowserRouter as Router,Route,Routes} from 'react-router-dom'
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import Header from './components/Header';
import Adminproducts from './components/Adminproducts';
import ProductAdd from './components/ProductAdd';
import { Contextapi } from './Contextapi';
import { useEffect, useState } from 'react';
import ProductUpdate from './components/Productupdate';
import Products from './components/Products';
import Cart from './components/Cart';

function App() {
 const[cart,setCart]=useState('')//JSON.parse(window.localStorage.getItem('cart')
 const[loginname,setLoginname]= useState(window.localStorage.getItem('email'))


 useEffect(()=>{
 window.localStorage.setItem('cart',JSON.stringify(cart))
},[cart])
 return ( 

    <>
    <Router>
      <Contextapi.Provider value={{loginname,setLoginname,cart,setCart}}>
      <Header/>
      <Routes>
        <Route path='/'element={<Login/>} ></Route>
        <Route path='/reg'element={<Register/>} ></Route>
        <Route path='/dashboard'element={<Dashboard/>} ></Route>
        <Route path='/aminproducts'element={<Adminproducts/>} ></Route>
        <Route path='/productadd'element={<ProductAdd/>} ></Route>
        <Route path='/productupdate/:id'element={<ProductUpdate/>} ></Route>
        <Route path='/products'element={<Products/>} ></Route>
        <Route path='/cart'element={<Cart/>} ></Route>
        
      </Routes>
      </Contextapi.Provider>
    </Router>





    </>
    
   );
}

export default App;