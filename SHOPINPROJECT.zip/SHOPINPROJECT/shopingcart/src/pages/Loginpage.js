import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Contextapi } from "../Contextapi";

function Loginpage() {
  const{setLoginname}=useContext(Contextapi)
    const navigate = useNavigate('')
    const[username,setUsername]=useState('')
    const[password,setPassword]=useState('')
    const[message,setMessage]=useState('')
    function handleform(e){
        e.preventDefault()
        const formdata={username,password}
        fetch('/api/login',{
            method:'POST',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((result)=>{return result.json()}).then((data)=>{
            console.log(data)
            if(data.status===200){
                window.localStorage.setItem('email',data.apiData.email)
                setLoginname(window.localStorage.getItem('email'))
               if(data.apiData.email==='admin@gmail.com'){
                navigate('/dashboard')
               }else{
                navigate('/products')
               }
            }else if(data.status===400){
               setMessage(data.message)
            }else{
                setMessage(data.message)
            }
        })
    }
 return ( 
        
     <section id='login'>
        <div className="container">
        <div className="row">
        <div className="col-md-4"></div>                
        <div className="col-md-4">
        <h2>Login Here</h2>
            {message}
        <form onSubmit={(e)=>{handleform(e)}}>
             <lable className="form-lable">email</lable>
            <input type='email' 
            value={username}
            onChange={(e)=>{setUsername(e.target.value)}} 
            className="form-control" 
             required/>
            <lable className="form-lable">password</lable>
            <input type='text'
            value={password}
             onChange={(e)=>{setPassword(e.target.value)}}
                className="form-control"
             required/>
                <button type="submit" className="form-control mt-2 mb-2 btn btn-success">Login</button>
            </form>
            <Link to='/reg'>you dont have account?click</Link>
       
            </div>
       <div className="col-md-4"></div>
       </div>

        </div>
      </section>
     );
}

export default Loginpage;