const clientMessages={
 code200:200,
 message200:'success',
 code201:201,
 message201:'Successful;y Created',
 code400:400,
 message400:'Bad Request',
 code500:500,
 message500:'Internal Server Error',
 messageUpdate:'Successfuly Updated'
       
}


module.exports=clientMessages