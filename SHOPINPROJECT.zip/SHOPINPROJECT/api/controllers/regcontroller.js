const Reg=require('../models/reg')
const helper=require('../helper/message')
console.log(helper)


exports.register=async(req,res)=>{
    const{username,password}=req.body 
    const check=await Reg.findOne({email:username})
    //console.log(check)
    try{
        if(check==null){
      const record=await Reg({email:username,password:password})
        record.save()
        res.json({
            status:helper.code201,
            message:helper.message201,
            apiData:record
        })
    }else{
        res.json({
            status:helper.code400,
            message:helper.message400, 
            apiData:username
        }) 
    }
    }catch (error){
        res.json({
            status:helper.code500,
            message:error.message, 
        })
    }
}

exports.login=async(req,res)=>{
 const{username,password}=req.body 
  try{
 const usercheck= await Reg.findOne({email:username})
 if(usercheck!==null){
    if(usercheck.password==password){
    res.json({
        status:helper.code200,
        message:helper.message200,
        apiData:usercheck
    })

    }else{
        res.json({
            status:helper.code400,
            message:'Wrong Credetails'
        })
    }
    }else{
        res.json({
            status:helper.code400,
            message:'Wrong Credetails'
        })
     }
 }catch(error){
    res.json({
        status:helper.code500,
        message:helper.message500
    })
  }

}


