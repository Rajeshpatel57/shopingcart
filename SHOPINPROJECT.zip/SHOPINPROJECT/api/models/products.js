const  mongoose = require("mongoose");

const productSchema= mongoose.Schema({
    name:String,
    desc:String,
    ldesc:String,
    price:String,
    status:{type:String,default:'IN STOCK'}
    
})



module.exports=mongoose.model('product',productSchema)


