const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const productc=require('../controllers/productcontroller')


router.post('/reg',regc.register)
router.post('/login',regc.login)
router.post('/productadd',productc.productadd)
router.get('/allproducts',productc.allproducts)
router.get('/singleproduct/:id',productc.singleproduct)
router.put('/productupdate/:id',productc.update)
router.get('/productinstock',productc.productinstock)
router.post('/productbyid',productc.productbyid)

module.exports=router